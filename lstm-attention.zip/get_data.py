"""
基于tushare获取股票的历史数据
"""
import tushare as ts

data = ts.get_hist_data('000977', end='20230314')
# ts.get_today_all()
data = data[['open', 'high', 'low', 'close', 'volume']]
print(data.head())

data = data.sort_index(
	ascending=True)

data.to_csv('000977.csv')
