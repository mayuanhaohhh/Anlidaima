import torch
from torch import nn
from torch.nn import MultiheadAttention


class AttnRNN(nn.Module):

    def __init__(self, input_size, hidden_size, target_size):
        super().__init__()
        # self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size * 2, target_size)
        self.attn = MultiheadAttention(hidden_size, 1, batch_first=True)

    def forward(self, inputs, return_attn=True):
        x, hn = self.lstm(inputs)
        seq_len = inputs.shape[0]
        attn_mask = (1 - torch.tril(torch.ones(seq_len, seq_len), diagonal=0)) * -1000
        x = x[:, -1]
        attn_x, attn_w = self.attn(x, x, x, attn_mask=attn_mask)
        mm = torch.cat([x, attn_x], dim=1)
        x = self.head(mm)
        if return_attn:
            return x, attn_w
        return x
