import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import math
import seaborn as sns
import datetime as dt
from datetime import datetime

sns.set_style("whitegrid")
from pandas.plotting import autocorrelation_plot
import matplotlib.pyplot as plt

# For creating model and training
import tensorflow as tf
from tensorflow.keras.layers import Conv1D, LSTM, Dense, Dropout, Bidirectional, TimeDistributed
from tensorflow.keras.layers import MaxPooling1D, Flatten
from tensorflow.keras.regularizers import L1, L2
from tensorflow.keras.metrics import Accuracy
from tensorflow.keras.metrics import RootMeanSquaredError

data = pd.read_excel('./data/002736.xlsx')
# data = pd.read_csv('../input/nifty50-stock-market-data/COALINDIA.csv')
# data = pd.read_csv('../input/stock-market-data/stock_market_data/nasdaq/csv/ABCO.csv')
# data = pd.read_csv('./data.csv')
# Any CSV or TXT file can be added here....
print(data.head())

data.plot(legend=True, subplots=True, figsize=(12, 6))
plt.show()

df = data

from sklearn.model_selection import train_test_split

X = []
Y = []
window_size = 100
for i in range(1, len(df) - window_size - 1, 1):
    first = df.iloc[i, 2]
    temp = []
    temp2 = []
    for j in range(window_size):
        temp.append((df.iloc[i + j, 2] - first) / first)
    temp2.append((df.iloc[i + window_size, 2] - first) / first)
    X.append(np.array(temp).reshape(100, 1))
    Y.append(np.array(temp2).reshape(1, 1))

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, shuffle=True)

train_X = np.array(x_train)
test_X = np.array(x_test)
train_Y = np.array(y_train)
test_Y = np.array(y_test)

train_X = train_X.reshape(train_X.shape[0], 1, 100, 1)
test_X = test_X.reshape(test_X.shape[0], 1, 100, 1)

print(len(train_X))
print(len(test_X))

# Load model
model = tf.keras.models.load_model("./model.h5")

predicted = model.predict(test_X)
test_label = test_Y.reshape(-1, 1)
predicted = np.array(predicted[:, 0]).reshape(-1, 1)
len_t = len(train_X)
for j in range(len_t, len_t + len(test_X)):
    temp = data.iloc[j, 2]
    test_label[j - len_t] = test_label[j - len_t] * temp + temp
    predicted[j - len_t] = predicted[j - len_t] * temp + temp
plt.plot(predicted, color='green', label='Predicted  Stock Price')
plt.plot(test_label, color='red', label='Real Stock Price')
plt.title(' Stock Price Prediction')
plt.xlabel('Time')
plt.ylabel(' Stock Price')
plt.legend()
plt.show()
