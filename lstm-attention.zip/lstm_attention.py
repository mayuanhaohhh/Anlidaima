import torch
import torch.nn as nn


class AttentionLSTM22(nn.Module):
    def __init__(self, feature_size, timestep, hidden_size, num_layers, num_heads, output_size):
        super(AttentionLSTM22, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        # LSTM
        self.lstm = nn.LSTM(feature_size, hidden_size, num_layers, batch_first=True)
        # 多头注意力
        self.attention = nn.MultiheadAttention(embed_dim=hidden_size, num_heads=num_heads,
                                               batch_first=True, dropout=0.5)
        # 全连接
        self.fc1 = nn.Linear(hidden_size * timestep, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_size)
        # 激活函数
        self.relu = nn.ReLU()

    def forward(self, x):
        out, _ = self.lstm(x)  # 默认h、C初始化为0
        # #注意力计算
        attention_output, _ = self.attention(out, out, out)  # flatten展开
        out = attention_output.flatten(start_dim=1)  # [32, 1280]#全连接层输出
        out = self.fc1(out)
        out = self.relu(out)
        out = self.fc2(out)
        out = self.relu(out)
        out = self.fc3(out)
        out = self.relu(out)
        return out
