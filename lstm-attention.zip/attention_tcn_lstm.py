import torch
import torch.nn as nn

class AttentionLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(AttentionLSTM, self).__init__()
        self.hidden_size = hidden_size

        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.attention = nn.Linear(hidden_size, 1)

    def forward(self, x):
        lstm_out, _ = self.lstm(x)

        attention_scores = self.attention(lstm_out).squeeze(2)
        attention_weights = torch.softmax(attention_scores, dim=1)

        attended_representation = torch.bmm(attention_weights.unsqueeze(1), lstm_out).squeeze(1)
        output = self.fc(attended_representation)

        return output


class TCN(nn.Module):
    def __init__(self, input_size, output_size, num_channels, kernel_size, dropout):
        super(TCN, self).__init__()
        self.tcn = nn.Sequential(
            nn.Conv1d(input_size, num_channels, kernel_size, padding=(kernel_size - 1) // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, num_channels, kernel_size, dilation=2, padding=(kernel_size - 1) * 2 // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, num_channels, kernel_size, dilation=4, padding=(kernel_size - 1) * 4 // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, num_channels, kernel_size, dilation=8, padding=(kernel_size - 1) * 8 // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, num_channels, kernel_size, dilation=16, padding=(kernel_size - 1) * 16 // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, num_channels, kernel_size, dilation=32, padding=(kernel_size - 1) * 32 // 2),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Conv1d(num_channels, output_size, kernel_size, padding=(kernel_size - 1) // 2)
        )

    def forward(self, x):
        return self.tcn(x).squeeze(2)


class AttentionTCN(nn.Module):
    def __init__(self, lstm_input_size, lstm_hidden_size, tcn_input_size, tcn_output_size, tcn_num_channels,
                 tcn_kernel_size, tcn_dropout):
        super(AttentionTCN, self).__init__()
        self.lstm = AttentionLSTM(lstm_input_size, lstm_hidden_size, tcn_input_size)
        self.tcn = TCN(tcn_input_size, tcn_output_size, tcn_num_channels, tcn_kernel_size, tcn_dropout)

    def forward(self, x):
        lstm_out = self.lstm(x)
        tcn_in = lstm_out.unsqueeze(2)
        tcn_out = self.tcn(tcn_in)
        return tcn_out

