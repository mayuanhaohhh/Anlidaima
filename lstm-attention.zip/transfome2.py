import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import torch.nn.functional as F
from torch.optim import Adam

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

data = (np.sin(np.linspace(-100, 100, 500)) + np.random.rand(500)-0.5).astype('float32')
plt.plot(data)
plt.show()


class RNN(nn.Module):

    def __init__(self, input_size, hidden_size, target_size):
        super(RNN, self).__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size, target_size)

    def forward(self, inputs):
        x, hn = self.rnn(inputs)
        x = self.head(x)
        return x

    @torch.no_grad()
    def predict(self, x, step=1):
        preds = []
        hn = None
        for i in range(step):
            x, hn = self.rnn(x, hn)
            x = self.head(x[:, -1:, :])
            preds.append(x)
        preds = torch.cat(preds, dim=1)
        return preds


class TrainDataset(Dataset):

    def __init__(self, data, lens=12):
        self.data = data
        self.lens = lens

    def __len__(self):
        return len(self.data) - self.lens

    def __getitem__(self, item):
        x = np.expand_dims(self.data[item: item + self.lens], axis=1)
        y = np.expand_dims(self.data[item + 1: item + self.lens + 1], axis=1)
        return x, y

def train(model, optimizer, train_dl, loss_fn, device="cpu"):
    model.train()
    model.to(device)
    losses = 0
    for (x, y) in train_dl:
        x, y = x.to(device), y.to(device)
        pred = model(x)
        loss = loss_fn(pred, y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        losses += loss.item() / len(train_dl)
    return np.mean(losses)

@torch.no_grad()
def valid(model, valid_dl, loss_fn, device='cpu'):
    model.eval()
    model.to(device)
    losses = 0
    for (x, y) in valid_dl:
        x, y = x.to(device), y.to(device)
        pred = model(x)
        loss = loss_fn(pred, y)
        losses += loss.item() / len(valid_dl)
    return np.mean(losses)

model = RNN(1, 12, 1)
train_ds = TrainDataset(data[:400])
train_dl = DataLoader(train_ds, batch_size=16, shuffle=True)

valid_ds = TrainDataset(data[400:480])
valid_dl = DataLoader(valid_ds, batch_size=16, shuffle=False)

optimizer = Adam(model.parameters(), lr=0.0001)

for i in range(60):
    trn_loss = train(model, optimizer, train_dl, nn.MSELoss())
    val_loss = valid(model, valid_dl, nn.MSELoss())
    print(f"epoch {i+1} train loss {trn_loss:.4f} val loss {val_loss:.4f}")

pred = model.predict(torch.tensor(data[480:493]).unsqueeze(1).unsqueeze(0), 7).squeeze().cpu().numpy()
plt.plot(data[493:])
plt.plot(pred)
plt.show()

from torch.nn import MultiheadAttention


class AttnRNN(nn.Module):

    def __init__(self, input_size, hidden_size, target_size):
        super().__init__()
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)
        self.head = nn.Linear(hidden_size * 2, target_size)
        self.attn = MultiheadAttention(hidden_size, 1, batch_first=True)

    def forward(self, inputs, return_attn=False):
        x, hn = self.rnn(inputs)
        seq_len = inputs.shape[1]
        attn_mask = (1 - torch.tril(torch.ones(seq_len, seq_len), diagonal=0)) * -200

        attn_x, attn_w = self.attn(x, x, x, attn_mask=attn_mask)
        x = self.head(torch.cat([x, attn_x], dim=2))
        if return_attn:
            return x, attn_w
        return x

model = AttnRNN(1, 12, 1)
train_ds = TrainDataset(data[:400])
train_dl = DataLoader(train_ds, batch_size=16, shuffle=True)

valid_ds = TrainDataset(data[400:480])
valid_dl = DataLoader(valid_ds, batch_size=16, shuffle=False)

optimizer = Adam(model.parameters(), lr=0.0001)

for i in range(60):
    trn_loss = train(model, optimizer, train_dl, nn.MSELoss())
    val_loss = valid(model, valid_dl, nn.MSELoss())
    print(f"epoch {i+1} train loss {trn_loss:.4f} val loss {val_loss:.4f}")


pred, attn = model(torch.tensor(data[480:492]).unsqueeze(0).unsqueeze(2), return_attn=True)
print(pred)