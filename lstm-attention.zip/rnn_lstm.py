import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel('./data/002736.xlsx')

print(data.head())
print("Data Shape -->", data.shape)
print(data.describe())
print("Do you have a null column? \n", data.isna().sum())

training_size = int(len(data) * 0.80)
data_len = len(data)

train, test = data[0:training_size], data[training_size:data_len]

print("Training Size --> ", training_size)
print("total length of data --> ", data_len)
print("Train length --> ", len(train))
print("Test length --> ", len(test))

# the part of data that we will use as training.
train = train.loc[:, ["open"]].values

from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler(feature_range=(0, 1))
train_scaled = scaler.fit_transform(train)

end_len = len(train_scaled)
X_train = []
y_train = []
timesteps = 40

for i in range(timesteps, end_len):
    X_train.append(train_scaled[i - timesteps:i, 0])
    y_train.append(train_scaled[i, 0])
X_train, y_train = np.array(X_train), np.array(y_train)

X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
print("X_train --> ", X_train.shape)
print("y_train shape --> ", y_train.shape)

from keras.models import Sequential
from keras.layers import Dense
from keras.layers import SimpleRNN
from keras.layers import Dropout

regressor = Sequential()

regressor.add(SimpleRNN(units=60, activation="tanh", return_sequences=True, input_shape=(X_train.shape[1], 1)))
regressor.add(Dropout(0.2))

regressor.add(SimpleRNN(units=50, activation="tanh", return_sequences=True))
regressor.add(Dropout(0.2))

regressor.add(SimpleRNN(units=50, activation="tanh", return_sequences=True))
regressor.add(Dropout(0.2))

regressor.add(SimpleRNN(units=50))
regressor.add(Dropout(0.2))

regressor.add(Dense(units=1))

regressor.compile(optimizer="adam", loss="mean_squared_error")

epochs = 150
batch_size = 32
regressor.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)

real_price = test.loc[:, ["open"]].values
print("Real Price Shape --> ", real_price.shape)

dataset_total = pd.concat((data["open"], test["open"]), axis=0)
inputs = dataset_total[len(dataset_total) - len(test) - timesteps:].values.reshape(-1, 1)
inputs = scaler.transform(inputs)

X_test = []

for i in range(timesteps, 161):
    X_test.append(inputs[i - timesteps:i, 0])
X_test = np.array(X_test)

print("X_test shape --> ", X_test.shape)

X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))
predict = regressor.predict(X_test)
predict = scaler.inverse_transform(predict)

plt.plot(real_price, color="red", label="Real Stock Price")
plt.plot(predict, color="black", label="Predict Stock Price")
plt.title("Stock Price Prediction")
plt.xlabel("Time")
plt.ylabel("Tesla Stock Price")
plt.legend()
plt.show()

from keras.layers import LSTM

regressor_l = Sequential()

regressor_l.add(LSTM(units=60, return_sequences=True, input_shape=(X_train.shape[1], 1)))
regressor_l.add(Dropout(0.2))

regressor_l.add(LSTM(units=50, return_sequences=True))
regressor_l.add(Dropout(0.2))

regressor_l.add(LSTM(units=50, return_sequences=True))
regressor_l.add(Dropout(0.2))

regressor_l.add(LSTM(units=50))
regressor_l.add(Dropout(0.2))

regressor_l.add(Dense(units=1))

regressor_l.compile(optimizer="adam", loss="mean_squared_error")
regressor_l.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)
predict_l = regressor_l.predict(X_test)
predict_l = scaler.inverse_transform(predict_l)
plt.plot(real_price, color="red", label="Real Stock Price")
plt.plot(predict_l, color="blue", label="Predict Stock Price LSTM")
plt.title("Stock Price Prediction")
plt.xlabel("Time")
plt.ylabel("Tesla Stock Price")
plt.legend()
plt.show()

plt.plot(real_price, color="red", label="Real Stock Price")
plt.plot(predict, color="green", label="Predict Stock Price Simple RNN")
plt.plot(predict_l, color="blue", label="Predict Stock Price LSTM")
plt.title("Stock Price Prediction")
plt.xlabel("Time")
plt.ylabel("Tesla Stock Price")
plt.legend()
plt.show()
